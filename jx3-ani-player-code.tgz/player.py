#!/usr/bin/env python3
"""MINA free player with the R4b companion-player chrome."""
from __future__ import annotations

import argparse
import re
import tkinter as tk
from pathlib import Path

import matplotlib

matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

from mina import load_mina, stick_edges
from min2 import load_min2_stick, sniff_magic
from mesh import bone_name_map, load_mesh, normalize_influences, skin_positions
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np

SAMPLES_DEFAULT = Path(__file__).resolve().parent / "samples"
FPS_DEFAULT = 33  # FbxCmd ms/frame -> ~30.3 fps; use 1/0.033
# Body meshes for Play skinned viewport — pick by clip body chip (never M2 on F1).
MESH_BY_BODY = {
    "F1": SAMPLES_DEFAULT / "mesh" / "f1_1008_body_hd.mesh",
    "F2": SAMPLES_DEFAULT / "mesh" / "f1_1008_body_hd.mesh",  # interim until dedicated F2 body
    "M1": SAMPLES_DEFAULT / "mesh" / "m2_1018_body_hd.mesh",
    "M2": SAMPLES_DEFAULT / "mesh" / "m2_1018_body_hd.mesh",
}
DEFAULT_BODY_MESH = MESH_BY_BODY["M2"]

# Fluent dark tokens shared with the slim UI theme.
BG = "#202020"
PANEL = "#2C2C2C"
ACCENT = "#60CDFF"
VIEW = "#0C0C0C"
TEXT = "#FFFFFF"
TEXT_SECONDARY = "#C8C8C8"
TEXT_DISABLED = "#6D6D6D"
INPUT = "#1A1A1A"
STROKE = "#3F3F3F"
ACCENT_HOVER = "#6BC6F0"

BODIES = ("F1", "F2", "M1", "M2")
_BODY_RE = re.compile(r"^(f1|f2|m1|m2)", re.IGNORECASE)


def _body_for_path(path: Path) -> str | None:
    """Match f1_xxx and compact f1s07cj… / m2s07cj… MovieEditor names."""
    match = _BODY_RE.match(path.name)
    return match.group(1).upper() if match else None


def _character_for_path(path: Path) -> str:
    match = _BODY_RE.match(path.name)
    if not match:
        return "Unknown"
    rest = path.name[match.end() :]
    if rest.startswith("_"):
        rest = rest[1:]
    for suffix in (".mesh.ani", ".ani"):
        if rest.endswith(suffix):
            rest = rest[: -len(suffix)]
            break
    # First underscore segment, or whole rest for compact names.
    return (rest.split("_", 1)[0] or "Unknown")


def _clip_name(path: Path) -> str:
    """Use a friendly fallback without pretending a basename is an AniTable name."""
    name = path.name
    for suffix in (".mesh.ani", ".ani"):
        if name.endswith(suffix):
            name = name[: -len(suffix)]
            break
    return name


class AniPlayer(tk.Tk):
    def __init__(self, samples_dir: Path, fps: float = 1000.0 / 33.0):
        super().__init__()
        self.title("JX3 Ani Player")
        self.configure(bg=BG)
        self.geometry("1100x720")
        self.minsize(900, 600)
        self.samples_dir = samples_dir
        self.fps = fps
        self.clip = None
        self.frame_i = 0
        self.playing = False
        self.loop = tk.BooleanVar(value=True)
        self.body_var = tk.StringVar(value="F1")
        self._after_id = None
        self.edges = []
        self._paths: list[Path] = []
        self._visible_paths: list[Path] = []
        self._character_ids: list[str] = []
        self.skinned = tk.BooleanVar(value=True)
        self._mesh = None
        self._mesh_map: dict = {}
        self._stick_rest = None
        self._mesh_label = ""

        self._build()
        self._load_clip_list()

    # ---------- R4b chrome ----------
    def _flat_button(self, parent, text, command, *, primary=False, width=None):
        bg = ACCENT if primary else PANEL
        fg = "#000000" if primary else TEXT
        button = tk.Button(
            parent,
            text=text,
            command=command,
            font=("Sans", 11),
            bg=bg,
            fg=fg,
            activebackground=ACCENT_HOVER if primary else "#353535",
            activeforeground="#000000" if primary else TEXT,
            disabledforeground=TEXT_DISABLED,
            relief="flat",
            borderwidth=0,
            highlightthickness=0 if primary else 1,
            highlightbackground=STROKE,
            highlightcolor=ACCENT,
            padx=13,
            pady=6,
            cursor="hand2",
        )
        if width is not None:
            button.configure(width=width)
        return button

    def _build(self):
        outer = tk.Frame(self, bg=BG)
        outer.pack(fill=tk.BOTH, expand=True, padx=20, pady=18)

        header = tk.Frame(outer, bg=BG)
        header.pack(fill=tk.X, pady=(0, 14))
        tk.Label(
            header,
            text="JX3 Ani Player  ·  free play companion",
            bg=BG,
            fg=TEXT,
            font=("Sans", 15),
        ).pack(anchor="w")
        tk.Label(
            header,
            text="Not MovieEditor — 动作 = clip  ·  body → character → Play",
            bg=BG,
            fg=TEXT_SECONDARY,
            font=("Sans", 10),
        ).pack(anchor="w", pady=(3, 0))

        shell = tk.Frame(outer, bg=BG)
        shell.pack(fill=tk.BOTH, expand=True)
        self._build_left_rail(shell)
        self._build_right_stage(shell)

    def _build_left_rail(self, parent):
        rail = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground=STROKE, width=246)
        rail.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 18))
        rail.pack_propagate(False)
        content = tk.Frame(rail, bg=PANEL)
        content.pack(fill=tk.BOTH, expand=True, padx=14, pady=14)

        self._section_label(content, "Body 体型")
        body_row = tk.Frame(content, bg=PANEL)
        body_row.pack(fill=tk.X, pady=(5, 17))
        self.body_buttons: dict[str, tk.Button] = {}
        for body in BODIES:
            button = tk.Button(
                body_row,
                text=body,
                command=lambda b=body: self._select_body(b),
                font=("Sans", 10),
                width=3,
                padx=2,
                pady=4,
                bg=INPUT,
                fg=TEXT,
                activebackground=ACCENT_HOVER,
                activeforeground="#000000",
                relief="flat",
                borderwidth=0,
                highlightthickness=1,
                highlightbackground=STROKE,
                cursor="hand2",
            )
            button.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(0, 5))
            self.body_buttons[body] = button

        self._section_label(content, "Character 角色")
        self.character_label = tk.Label(
            content,
            text="No character selected",
            bg=PANEL,
            fg=TEXT_SECONDARY,
            anchor="w",
            font=("Sans", 10),
        )
        self.character_label.pack(fill=tk.X, pady=(5, 10))
        self.character_list = tk.Listbox(
            content,
            height=3,
            bg=INPUT,
            fg=TEXT,
            selectbackground="#3A3A3A",
            selectforeground=TEXT,
            highlightthickness=1,
            highlightbackground=STROKE,
            relief="flat",
            borderwidth=0,
            activestyle="none",
            font=("Sans", 10),
            exportselection=False,
        )
        self.character_list.pack(fill=tk.X, pady=(0, 16))
        self.character_list.bind("<<ListboxSelect>>", self._on_character_select)

        self._section_label(content, "动作 Clip")
        self.clip_hint = tk.Label(
            content,
            text="Ani / Tani resource · basename fallback",
            bg=PANEL,
            fg=TEXT_SECONDARY,
            anchor="w",
            font=("Sans", 9),
        )
        self.clip_hint.pack(fill=tk.X, pady=(4, 7))
        self.clip_list = tk.Listbox(
            content,
            height=7,
            bg=INPUT,
            fg=TEXT,
            selectbackground=ACCENT,
            selectforeground="#000000",
            highlightthickness=1,
            highlightbackground=STROKE,
            relief="flat",
            borderwidth=0,
            activestyle="none",
            font=("Sans", 10),
            exportselection=False,
        )
        self.clip_list.pack(fill=tk.X, pady=(0, 14))
        self.clip_list.bind("<<ListboxSelect>>", lambda _e: self._on_select_clip())

        bones_label = tk.Frame(content, bg=PANEL)
        bones_label.pack(fill=tk.X)
        self._section_label(bones_label, "Bones", side=tk.LEFT)
        self.bone_count_label = tk.Label(
            bones_label, text="", bg=PANEL, fg=TEXT_SECONDARY, font=("Sans", 9)
        )
        self.bone_count_label.pack(side=tk.RIGHT)
        self.bone_list = tk.Listbox(
            content,
            height=6,
            bg=INPUT,
            fg=TEXT_SECONDARY,
            selectbackground="#3A3A3A",
            selectforeground=TEXT,
            highlightthickness=1,
            highlightbackground=STROKE,
            relief="flat",
            borderwidth=0,
            activestyle="none",
            font=("Sans", 9),
            exportselection=False,
        )
        self.bone_list.pack(fill=tk.BOTH, expand=True, pady=(5, 0))
        self._paint_body_buttons()

    def _section_label(self, parent, text, side=tk.TOP):
        tk.Label(
            parent,
            text=text,
            bg=PANEL,
            fg=TEXT_SECONDARY,
            font=("Sans", 10),
        ).pack(side=side, anchor="w")

    def _build_right_stage(self, parent):
        stage = tk.Frame(parent, bg=BG)
        stage.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        viewport_card = tk.Frame(stage, bg=VIEW, highlightthickness=1, highlightbackground=STROKE)
        viewport_card.pack(fill=tk.BOTH, expand=True)
        self.fig = Figure(figsize=(6, 3.6), dpi=100, facecolor=VIEW)
        self.ax = self.fig.add_subplot(111, projection="3d", facecolor=VIEW)
        self.canvas = FigureCanvasTkAgg(self.fig, master=viewport_card)
        self.canvas.get_tk_widget().configure(bg=VIEW, highlightthickness=0, borderwidth=0)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        self.meta = tk.Label(
            stage,
            text="Choose a 动作 (clip) to play.",
            bg=BG,
            fg=TEXT_SECONDARY,
            anchor="w",
            font=("Sans", 10),
        )
        self.meta.pack(fill=tk.X, pady=(8, 8))

        transport = tk.Frame(stage, bg=PANEL, highlightthickness=1, highlightbackground=STROKE)
        transport.pack(fill=tk.X)
        controls = tk.Frame(transport, bg=PANEL)
        controls.pack(fill=tk.X, padx=14, pady=(12, 8))
        self.play_button = self._flat_button(controls, "▶  Play", self.play, primary=True)
        self.play_button.pack(side=tk.LEFT, padx=(0, 8))
        self._flat_button(controls, "▣  Pause", self.pause).pack(side=tk.LEFT, padx=(0, 8))
        self._flat_button(controls, "▣  Stop", self.stop).pack(side=tk.LEFT, padx=(0, 8))
        self.loop_button = tk.Checkbutton(
            controls,
            text="☑  Loop",
            variable=self.loop,
            command=self._paint_loop_button,
            indicatoron=False,
            font=("Sans", 11),
            padx=13,
            pady=6,
            relief="flat",
            borderwidth=0,
            highlightthickness=1,
            highlightbackground=ACCENT,
            bg=PANEL,
            fg=ACCENT,
            activebackground="#353535",
            activeforeground=TEXT,
            selectcolor=PANEL,
            cursor="hand2",
        )
        self.loop_button.pack(side=tk.LEFT)
        self.skinned_button = tk.Checkbutton(
            controls,
            text="☑  Skinned",
            variable=self.skinned,
            command=self._paint_skinned_button,
            indicatoron=False,
            font=("Sans", 11),
            padx=13,
            pady=6,
            relief="flat",
            borderwidth=0,
            highlightthickness=1,
            highlightbackground=ACCENT,
            bg=PANEL,
            fg=ACCENT,
            activebackground="#353535",
            activeforeground=TEXT,
            selectcolor=PANEL,
            cursor="hand2",
        )
        self.skinned_button.pack(side=tk.LEFT, padx=(8, 0))
        self._paint_skinned_button()

        scrub_row = tk.Frame(transport, bg=PANEL)
        scrub_row.pack(fill=tk.X, padx=14, pady=(0, 12))
        self.scrub = tk.Scale(
            scrub_row,
            from_=0,
            to=0,
            orient=tk.HORIZONTAL,
            showvalue=False,
            bg=PANEL,
            fg=TEXT,
            troughcolor=INPUT,
            activebackground=ACCENT,
            highlightthickness=0,
            borderwidth=0,
            sliderlength=16,
            command=self._on_scrub,
        )
        self.scrub.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 12))
        self.time_lbl = tk.Label(scrub_row, text="0 / 0", bg=PANEL, fg=TEXT_SECONDARY, font=("Sans", 9))
        self.time_lbl.pack(side=tk.RIGHT)

    def _paint_loop_button(self):
        selected = self.loop.get()
        self.loop_button.configure(
            bg=ACCENT if selected else PANEL,
            fg="#000000" if selected else TEXT,
            highlightbackground=ACCENT if selected else STROKE,
            activeforeground="#000000" if selected else TEXT,
        )

    def _paint_skinned_button(self):
        selected = self.skinned.get()
        self.skinned_button.configure(
            bg=ACCENT if selected else PANEL,
            fg="#000000" if selected else TEXT,
            highlightbackground=ACCENT if selected else STROKE,
            activeforeground="#000000" if selected else TEXT,
        )
        if self.clip:
            self._draw_frame()

    def _paint_body_buttons(self):
        selected = self.body_var.get()
        for body, button in self.body_buttons.items():
            button.configure(
                bg=ACCENT if body == selected else INPUT,
                fg="#000000" if body == selected else TEXT,
                highlightbackground=ACCENT if body == selected else STROKE,
            )

    # ---------- Catalog / selection ----------
    def _load_clip_list(self):
        # Top-level samples plus plot/ and pss/ so Play opens staged assets without hunting.
        candidates = []
        for pattern in ("*.ani", "*.mesh.ani"):
            candidates.extend(self.samples_dir.glob(pattern))
        for sub in ("plot", "pss", "player"):
            subdir = self.samples_dir / sub
            if subdir.is_dir():
                candidates.extend(subdir.glob("*.ani"))
                candidates.extend(subdir.glob("*.mesh.ani"))
        # Recursive under moves/ (incl. fenglaiwushan/) — .ani only, skip .tani packs.
        moves_dir = self.samples_dir / "player" / "moves"
        if moves_dir.is_dir():
            candidates.extend(moves_dir.rglob("*.ani"))
            candidates.extend(moves_dir.rglob("*.mesh.ani"))
        candidates = sorted(candidates, key=lambda p: str(p).lower())
        seen = set()
        self._paths = []
        for path in candidates:
            resolved = path.resolve()
            if resolved not in seen:
                seen.add(resolved)
                self._paths.append(path)
        inferred = next((_body_for_path(path) for path in self._paths if _body_for_path(path)), "F1")
        self.body_var.set(inferred)
        self._refresh_catalog(select_first=True)
        if not self._paths:
            self.meta.configure(text=f"No .ani in {self.samples_dir}")

    def _refresh_catalog(self, select_first=False):
        selected_body = self.body_var.get()
        self._paint_body_buttons()
        self._visible_paths = [p for p in self._paths if _body_for_path(p) in (None, selected_body)]
        self._character_ids = sorted({_character_for_path(p) for p in self._visible_paths})
        self.character_list.delete(0, tk.END)
        for character in self._character_ids:
            self.character_list.insert(tk.END, f"•  {character}  ({selected_body})")
        self.clip_list.delete(0, tk.END)
        for path in self._visible_paths:
            self.clip_list.insert(tk.END, _clip_name(path))
        if self._visible_paths and select_first:
            self.character_list.selection_set(0)
            self.character_list.see(0)
            self.clip_list.selection_set(0)
            self.clip_list.see(0)
            self._on_select_clip()
            # Keep highlight after character sync (exportselection=False is the real fix).
            self.clip_list.selection_set(0)
            self.clip_list.see(0)
        elif not self._visible_paths:
            self.character_label.configure(text="No character for this body")
            self.meta.configure(text="Choose a body type to list characters.")
            self.clip_hint.configure(text="No clips indexed for this body")
        else:
            self.clip_hint.configure(text="Ani / Tani resource · basename fallback")

    def _select_body(self, body: str):
        self.pause()
        self.body_var.set(body)
        self.clip = None
        self.frame_i = 0
        self._refresh_catalog(select_first=True)
        self._paint_body_buttons()

    def _on_character_select(self, _event=None):
        selection = self.character_list.curselection()
        if selection:
            self.character_label.configure(text=f"{self._character_ids[selection[0]]}  ·  {self.body_var.get()}")

    def _on_select_clip(self):
        sel = self.clip_list.curselection()
        if not sel or sel[0] >= len(self._visible_paths):
            return
        path = self._visible_paths[sel[0]]
        self.body_var.set(_body_for_path(path) or self.body_var.get())
        self._paint_body_buttons()
        character = _character_for_path(path)
        if character in self._character_ids:
            index = self._character_ids.index(character)
            self.character_list.selection_clear(0, tk.END)
            self.character_list.selection_set(index)
            self.character_list.see(index)
            self.character_label.configure(text=f"{character}  ·  {self.body_var.get()}")
        try:
            magic = sniff_magic(path)
            if magic == "MINA":
                self.clip = load_mina(path)
            elif magic == "MIN2":
                self.clip = load_min2_stick(path)
            else:
                raise ValueError(f"unsupported ani magic {magic!r}")
        except Exception as error:  # keep missing/bad resources inline, not modal
            self.clip = None
            self.meta.configure(text=f"Clip indexed but unavailable: {error}")
            return
        self.edges = stick_edges(self.clip.bone_names)
        self.frame_i = 0
        self.scrub.configure(to=max(0, self.clip.frame_count - 1))
        self.scrub.set(0)
        self.bone_list.delete(0, tk.END)
        for name in self.clip.bone_names:
            self.bone_list.insert(tk.END, name)
        self.bone_count_label.configure(text=f"{self.clip.bone_count} bones")
        self._bind_body_mesh(path, magic)
        mesh_note = f"  ·  skinned {self._mesh_label}" if self._mesh is not None else ""
        self.meta.configure(
            text=f"Clip: {_clip_name(path)}  ·  {self.clip.frame_count} frames  ·  {self.clip.tex_hint or 'MINA'}{mesh_note}"
        )
        self.clip_hint.configure(text=f"{_clip_name(path)}  ·  Ani  ·  {self.body_var.get()}")
        self._draw_frame()

    def _bind_body_mesh(self, clip_path: Path, magic: str) -> None:
        """Attach body mesh matching clip body chip for MIN2; clear otherwise."""
        self._mesh = None
        self._mesh_map = {}
        self._stick_rest = None
        self._mesh_label = ""
        if magic != "MIN2":
            return
        body = _body_for_path(clip_path) or self.body_var.get()
        mesh_path = MESH_BY_BODY.get(body, DEFAULT_BODY_MESH)
        # Hard rule: never put M2 沈眠风 mesh on an F1/F2 clip.
        if body in ("F1", "F2") and "m2_" in mesh_path.name.lower():
            self._mesh_label = f"F1/F2 mesh missing for {body}"
            return
        if not mesh_path.is_file():
            self._mesh_label = f"mesh missing ({mesh_path.name})"
            return
        try:
            mesh = load_mesh(mesh_path)
            normalize_influences(mesh)
            mapping = bone_name_map(mesh, list(self.clip.bone_names))
            if len(mapping) < 8:
                self._mesh_label = f"map too sparse ({len(mapping)})"
                return
            self._mesh = mesh
            self._mesh_map = mapping
            # Prefer RQ matrices_at bind; fall back to positions if clip lacks API.
            if hasattr(self.clip, "matrices_at"):
                self._stick_rest = self.clip.matrices_at(0)
            else:
                self._stick_rest = self.clip.positions_at(0)
            self._mesh_label = f"{mesh_path.name} ({len(mapping)}/{len(mesh.bones)} bones)"
        except Exception as error:
            self._mesh_label = f"mesh bind fail: {error}"

    # ---------- Transport ----------
    def _on_scrub(self, val):
        if not self.clip:
            return
        self.frame_i = int(float(val))
        if not self.playing:
            self._draw_frame()

    def play(self):
        if not self.clip:
            return
        if self.playing:
            return
        self.playing = True
        self._tick()

    def pause(self):
        self.playing = False
        if self._after_id:
            self.after_cancel(self._after_id)
            self._after_id = None

    def stop(self):
        self.pause()
        self.frame_i = 0
        self.scrub.set(0)
        self._draw_frame()

    def _tick(self):
        if not self.playing or not self.clip:
            return
        self._draw_frame()
        self.frame_i += 1
        if self.frame_i >= self.clip.frame_count:
            if self.loop.get():
                self.frame_i = 0
            else:
                self.frame_i = self.clip.frame_count - 1
                self.playing = False
                self._after_id = None
                return
        self.scrub.set(self.frame_i)
        delay = max(1, int(1000 / self.fps))
        self._after_id = self.after(delay, self._tick)

    def _draw_frame(self):
        if not self.clip:
            return
        f = self.frame_i
        positions = self.clip.positions_at(f)

        self.ax.clear()
        self.ax.set_facecolor(VIEW)

        drew_mesh = False
        if self.skinned.get() and self._mesh is not None and self._stick_rest is not None:
            try:
                if hasattr(self.clip, "matrices_at"):
                    pose_for_skin = self.clip.matrices_at(f)
                else:
                    pose_for_skin = positions
                verts = skin_positions(self._mesh, self._stick_rest, pose_for_skin, self._mesh_map)
                # Y-up display remap (x, z, y) matching Dev4 proof renderer.
                disp = np.column_stack([verts[:, 0], verts[:, 2], verts[:, 1]])
                tris = disp[self._mesh.faces]
                coll = Poly3DCollection(
                    tris,
                    linewidths=0.02,
                    edgecolors=(0.2, 0.22, 0.25, 0.15),
                    facecolors=(0.55, 0.72, 0.88, 0.92),
                )
                self.ax.add_collection3d(coll)
                mins = disp.min(axis=0)
                maxs = disp.max(axis=0)
                center = (mins + maxs) * 0.5
                span = float((maxs - mins).max()) * 0.55 + 1.0
                self.ax.set_xlim(center[0] - span, center[0] + span)
                self.ax.set_ylim(center[1] - span, center[1] + span)
                self.ax.set_zlim(center[2] - span, center[2] + span)
                self.ax.view_init(elev=12, azim=-60)
                drew_mesh = True
            except Exception:
                drew_mesh = False

        if not drew_mesh:
            xs = [p[0] for p in positions]
            ys = [p[1] for p in positions]
            zs = [p[2] for p in positions]
            self.ax.scatter(xs, ys, zs, c=ACCENT, s=18, depthshade=True)
            for pi, ci in self.edges:
                self.ax.plot(
                    [positions[pi][0], positions[ci][0]],
                    [positions[pi][1], positions[ci][1]],
                    [positions[pi][2], positions[ci][2]],
                    color="#AAAAAA",
                    linewidth=1.2,
                )
            allv = xs + ys + zs
            if allv:
                lo, hi = min(allv), max(allv)
                pad = (hi - lo) * 0.1 + 1.0
                self.ax.set_xlim(lo - pad, hi + pad)
                self.ax.set_ylim(lo - pad, hi + pad)
                self.ax.set_zlim(lo - pad, hi + pad)

        self.ax.set_xticks([])
        self.ax.set_yticks([])
        self.ax.set_zticks([])
        self.ax.xaxis.pane.fill = False
        self.ax.yaxis.pane.fill = False
        self.ax.zaxis.pane.fill = False
        t = f / self.fps
        total = (self.clip.frame_count - 1) / self.fps
        mode = "skinned" if drew_mesh else "stick"
        self.time_lbl.configure(text=f"{t:0.2f} / {total:0.2f}s   ·   frame {f}   ·   {mode}")
        self.canvas.draw_idle()


def main():
    ap = argparse.ArgumentParser(description="MINA .mesh.ani free player (R4b companion UI)")
    ap.add_argument(
        "--samples",
        type=Path,
        default=SAMPLES_DEFAULT,
        help="Directory of .ani / .mesh.ani samples",
    )
    ap.add_argument("--fps", type=float, default=1000.0 / 33.0, help="Playback FPS (FbxCmd default 33ms)")
    args = ap.parse_args()
    samples = args.samples
    if not samples.exists():
        alt = Path("/workspace/jx3-movie-editor-research/samples")
        if alt.exists():
            samples = alt
    app = AniPlayer(samples, fps=args.fps)
    app.mainloop()


if __name__ == "__main__":
    main()
