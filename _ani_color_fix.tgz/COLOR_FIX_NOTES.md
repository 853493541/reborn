# FBX albedo color fix (lime/orange → normal skin/cloth)

## Symptom
Ani Player FBX viewport showed psychedelic lime/orange albedo on 花萝 even though
the HUD said `textured (map-viewer preset)`. Embedded FBX maps were wrong or
pointed at non-albedo data (Normal / MRE / Specular mis-bound as `material.map`).

## Map-viewer lesson (source of truth)
From `prepareAnchorRigMaterials` / actor-viewer `prepareMaterials`:

1. `renderer.outputColorSpace = THREE.SRGBColorSpace`
2. Per mesh material: zero `emissive` when there is no `emissiveMap`; `DoubleSide`;
   raise `alphaTest` when transparent / zero.
3. **Override `material.map` only** with `{materialName}_Diffuse.png` (or `.tga`)
   from the actor `tex/` folder via `TextureLoader`, with
   `tex.colorSpace = THREE.SRGBColorSpace` (and `flipY = false` for FBX UVs).
4. After override: `material.color.setHex(0xffffff)` so tint does not multiply albedo.
5. Also set `material.map.colorSpace` / `emissiveMap.colorSpace` to
   `THREE.SRGBColorSpace` on any leftover embedded FBX textures.
6. **Never** bind Normal / MRE / Specular into `material.map`. Those belong in
   `normalMap` / other slots if used at all — putting them in `map` is what
   produces the lime/orange “psychedelic” look.

Lookup matches map-viewer `findPresetTextureFile`: lowercase
`{materialName}_Diffuse.png|.tga` against a tex-directory file list
(`/api/f1_hualuo_textures` or `diffuse_manifest.json`).

## Files touched
- `web/fbx_viewport.js` — full prepare pass after FBX load (was missing).
- `viewport_fbx/index.html` — aligned alphaTest + leftover sRGB + Diffuse-only guard.
- `web/diffuse_manifest.json` — Diffuse filename list for standalone http.server.
