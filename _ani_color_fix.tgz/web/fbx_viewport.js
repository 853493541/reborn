/**
 * F1 花萝 textured FBX viewport — mirrors map-viewer ensurePlayerAnchorRig load path.
 * Color fix (same as map-viewer actor-viewer prepareMaterials /
 * actor-animation-player prepareAnchorRigMaterials):
 *   - renderer.outputColorSpace = SRGBColorSpace
 *   - override material.map with {matName}_Diffuse.png from tex/
 *   - tex.colorSpace = SRGBColorSpace; flipY = false
 *   - material.color = white after override
 *   - zero emissive unless emissiveMap
 *   - never bind Normal/MRE/Specular into material.map
 * Pose feed: poll /runtime/pose.json written by fbx_actor.apply_pose().
 */
import * as THREE from 'three';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';

const params = new URLSearchParams(location.search);
const FBX_URL = params.get('fbx') || './samples/actor_presets/f1_hualuo/hualuo_no_anim.fbx';
const TEX_BASE = (params.get('tex') || './samples/actor_presets/f1_hualuo/tex/').replace(/\/?$/, '/');
const POSE_URL = params.get('pose') || './runtime/pose.json';
const CLOSEUP = params.get('closeup') === '1';

const hud = document.getElementById('hud');
const canvas = document.getElementById('c');

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setClearColor(0x080c12, 1);
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 5000);
camera.position.set(0, 150, CLOSEUP ? 220 : 400);
camera.lookAt(0, 80, 0);

const hemi = new THREE.HemisphereLight(0xffffff, 0x404050, 1.0);
hemi.position.set(0, 200, 0);
scene.add(hemi);
const key = new THREE.DirectionalLight(0xffffff, 0.85);
key.position.set(150, 300, 200);
scene.add(key);

const grid = new THREE.GridHelper(800, 40, 0x1a2a3a, 0x111a24);
scene.add(grid);

let root = null;
const boneByName = new Map();
let lastPoseVer = -1;

const textureLoader = new THREE.TextureLoader();
textureLoader.setPath(TEX_BASE);

let diffuseFiles = [];

async function loadDiffuseManifest() {
  try {
    const res = await fetch(new URL('./diffuse_manifest.json', location.href), { cache: 'no-store' });
    if (res.ok) {
      const list = await res.json();
      if (Array.isArray(list)) diffuseFiles = list.map(String);
    }
  } catch (_) { /* optional */ }
  if (!diffuseFiles.length) {
    // Fallback: common F1 花萝 Diffuse set (same names as samples/.../tex)
    diffuseFiles = [
      'f1_1004_bang_hd_s0_c0_Diffuse.png', 'f1_1004_bang_hd_s1_c0_Diffuse.png', 'f1_1004_bang_hd_s2_c0_Diffuse.png',
      'f1_1004_face_hd_s0_c0_Diffuse.png', 'f1_1004_face_hd_s1_c0_Diffuse.png', 'f1_1004_face_hd_s2_c0_Diffuse.png', 'f1_1004_face_hd_s3_c0_Diffuse.png',
      'f1_1004_head_hd_s0_c0_Diffuse.png', 'f1_1004_head_hd_s1_c0_Diffuse.png',
      'f1_1004_lglove_hd_s0_c0_Diffuse.png', 'f1_1004_rglove_hd_s0_c0_Diffuse.png',
      'f1_1004_plait_hd_s0_c0_Diffuse.png', 'f1_1004_plait_hd_s1_c0_Diffuse.png', 'f1_1004_plait_hd_s2_c0_Diffuse.png',
      'f1_2227_belt_hd_s0_c0_Diffuse.png',
      'f1_2227_body_hd_s0_c0_Diffuse.png', 'f1_2227_body_hd_s1_c0_Diffuse.png', 'f1_2227_body_hd_s2_c0_Diffuse.png',
      'f1_2227_body_hd_s3_c0_Diffuse.png', 'f1_2227_body_hd_s4_c0_Diffuse.png',
      'f1_2227_hand_hd_s0_c0_Diffuse.png', 'f1_2227_hand_hd_s1_c0_Diffuse.png', 'f1_2227_hand_hd_s2_c0_Diffuse.png',
      'f1_2227_hat_hd_s0_c0_Diffuse.png', 'f1_2227_hat_hd_s1_c0_Diffuse.png', 'f1_2227_hat_hd_s2_c0_Diffuse.png',
      'f1_2227_leg_hd_s0_c0_Diffuse.png', 'f1_2227_leg_hd_s1_c0_Diffuse.png',
    ];
  }
}

function matchDiffuse(matName) {
  const name = String(matName || '').trim();
  if (!name) return null;
  const exact = `${name}_Diffuse.png`;
  if (diffuseFiles.includes(exact)) return exact;
  const hit = diffuseFiles.find((f) => f.startsWith(name) && f.endsWith('_Diffuse.png'));
  if (hit) return hit;
  // Only accept includes-match when the Diffuse stem is a full token in the material name
  // (avoids binding Normal/MRE by accident — those are not in diffuseFiles).
  const hit2 = diffuseFiles.find((f) => {
    const stem = f.replace(/_Diffuse\.png$/, '');
    return name === stem || name.includes(stem);
  });
  return hit2 || null;
}

function loadTexture(file, colorSpace) {
  return new Promise((resolve) => {
    textureLoader.load(
      file,
      (tex) => {
        if (colorSpace) tex.colorSpace = colorSpace;
        tex.flipY = false;
        resolve(tex);
      },
      undefined,
      () => resolve(null),
    );
  });
}

/**
 * Map-viewer prepareAnchorRigMaterials / actor-viewer prepareMaterials port.
 * Without this pass FBX embedded maps (often Normal/MRE-ish) show as lime/orange albedo.
 */
async function prepareAnchorRigMaterials(object) {
  await loadDiffuseManifest();
  const tasks = [];
  let mapped = 0;
  object.traverse((o) => {
    if (!o.isMesh && !o.isSkinnedMesh) return;
    o.frustumCulled = false;
    o.castShadow = false;
    o.receiveShadow = false;
    const mats = Array.isArray(o.material) ? o.material : [o.material];
    for (const mat of mats) {
      if (!mat) continue;
      mat.side = THREE.DoubleSide;
      if (mat.emissive && !mat.emissiveMap) mat.emissive.setRGB(0, 0, 0);
      if (mat.transparent || mat.alphaTest === 0) {
        mat.alphaTest = Math.max(mat.alphaTest || 0, 0.3);
      }
      const file = matchDiffuse(mat.name);
      if (file) {
        tasks.push(
          loadTexture(file, THREE.SRGBColorSpace).then((tex) => {
            if (tex) {
              mat.map = tex;
              if (mat.color) mat.color.setHex(0xffffff);
              mat.needsUpdate = true;
              mapped += 1;
            }
          }),
        );
      } else if (mat.map) {
        // Enforce sRGB on any map still pointing at the FBX embedded texture.
        mat.map.colorSpace = THREE.SRGBColorSpace;
        mat.map.flipY = false;
        if (mat.color) mat.color.setHex(0xffffff);
        mat.needsUpdate = true;
      }
      if (mat.emissiveMap) mat.emissiveMap.colorSpace = THREE.SRGBColorSpace;
    }
  });
  await Promise.all(tasks);
  return mapped;
}

function resize() {
  const w = canvas.clientWidth || window.innerWidth;
  const h = canvas.clientHeight || window.innerHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w / Math.max(h, 1);
  camera.updateProjectionMatrix();
}

window.addEventListener('resize', resize);
resize();

function indexBones(obj) {
  boneByName.clear();
  obj.traverse((o) => {
    if (o.isBone || o.type === 'Bone') {
      boneByName.set(o.name, o);
      boneByName.set(o.name.toLowerCase(), o);
    }
  });
}

function normBone(n) {
  return String(n || '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function applyMatrices(matrices, boneNames) {
  if (!root || !matrices || !boneNames) return;
  const n = Math.min(matrices.length, boneNames.length);
  for (let i = 0; i < n; i++) {
    const name = boneNames[i];
    const bone = boneByName.get(name) || boneByName.get(normBone(name)) || boneByName.get(normBone(name).replace(/^bip01/, 'bip01 '));
    if (!bone) continue;
    const m = matrices[i];
    if (!m || m.length < 12) continue;
    const e = bone.matrix;
    e.set(
      m[0], m[1], m[2], m[3],
      m[4], m[5], m[6], m[7],
      m[8], m[9], m[10], m[11],
      0, 0, 0, 1,
    );
    e.transpose();
    bone.matrixAutoUpdate = false;
    bone.updateMatrixWorld(true);
  }
  root.traverse((o) => {
    if (o.isSkinnedMesh) o.skeleton?.update();
  });
}

async function pollPose() {
  try {
    const res = await fetch(`${POSE_URL}?t=${Date.now()}`, { cache: 'no-store' });
    if (!res.ok) return;
    const pose = await res.json();
    if (pose.v === lastPoseVer) return;
    lastPoseVer = pose.v;
    applyMatrices(pose.matrices, pose.bone_names);
    hud.textContent = `花萝 FBX · frame ${pose.frame ?? '—'} · bones ${boneByName.size / 2 | 0}`;
  } catch (_) { /* pose file optional until apply_pose */ }
}

const loader = new FBXLoader();
loader.setResourcePath(TEX_BASE);
hud.textContent = `loading ${FBX_URL}…`;

loader.load(
  FBX_URL,
  async (obj) => {
    root = obj;
    root.scale.setScalar(1);
    scene.add(root);
    indexBones(root);
    const mapped = await prepareAnchorRigMaterials(root);
    const box = new THREE.Box3().setFromObject(root);
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();
    box.getSize(size);
    box.getCenter(center);
    if (CLOSEUP) {
      camera.position.set(center.x + size.x * 0.15, center.y + size.y * 0.35, center.z + Math.max(size.y, size.z) * 1.1);
      camera.lookAt(center.x, center.y + size.y * 0.25, center.z);
    } else {
      camera.position.set(center.x, center.y + size.y * 0.4, center.z + Math.max(size.x, size.y, size.z) * 1.8);
      camera.lookAt(center.x, center.y + size.y * 0.2, center.z);
    }
    let bc = 0;
    root.traverse((o) => { if (o.isBone) bc++; });
    hud.textContent = `花萝 FBX ready · ${bc} bones · Diffuse ${mapped}/${diffuseFiles.length} (map-viewer color fix)`;
    window.__FBX_READY__ = { bones: bc, fbx: FBX_URL, tex: TEX_BASE, diffuseMapped: mapped };
    window.dispatchEvent(new Event('fbx-ready'));
  },
  undefined,
  (err) => {
    hud.textContent = `FBX load failed: ${err?.message || err}`;
    window.__FBX_ERROR__ = String(err?.message || err);
    console.error(err);
  },
);

function frame() {
  resize();
  pollPose();
  renderer.render(scene, camera);
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

window.fbxViewport = {
  applyPose: (pose) => {
    lastPoseVer = pose.v ?? lastPoseVer + 1;
    applyMatrices(pose.matrices, pose.bone_names);
  },
  getBoneNames: () => [...new Set([...boneByName.keys()])],
};
